# 2Dシューティングゲーム

![](https://github.com/unity3d-jp-tutorials/2d-shooting-game/wiki/images/Home/top_thumb_intro.jpg)


チュートリアルページは[こちら](https://github.com/unity3d-jp-tutorials/2d-shooting-game/wiki)
